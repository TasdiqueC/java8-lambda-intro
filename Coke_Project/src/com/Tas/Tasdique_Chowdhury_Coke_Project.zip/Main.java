package com.Tas;

public class Main {

    public static void main(String[] args) {
        VendingMachine.menu(1);
    }
}
